import os, sqlite3, random, logging
from datetime import datetime, timedelta, timezone
from pathlib import Path
from threading import Thread
from flask import Flask
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import Application, CommandHandler, CallbackQueryHandler, MessageHandler, ContextTypes, filters

TOKEN = os.getenv("BOT_TOKEN", "").strip()
ADMINS = {int(x) for x in os.getenv("ADMIN_IDS", "").split(",") if x.strip().isdigit()}
PORT = int(os.getenv("PORT", "10000"))
GIFT_MIN = int(os.getenv("DAILY_DISCOUNT_MIN", "5"))
GIFT_MAX = int(os.getenv("DAILY_DISCOUNT_MAX", "20"))
ANIMATION = os.getenv("GIFT_ANIMATION", "").strip()
DB = "forum_bot.sqlite3"
logging.basicConfig(level=logging.INFO)
log = logging.getLogger("wezing-forum")
web = Flask(__name__)

@web.get("/")
def health():
    return "WEZING RUSSIA FORUM BOT: OK"

def conn():
    c = sqlite3.connect(DB)
    c.row_factory = sqlite3.Row
    return c

def init_db():
    with conn() as c:
        c.executescript("""
        CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY, username TEXT, name TEXT);
        CREATE TABLE IF NOT EXISTS recruitment(kind TEXT PRIMARY KEY, opened INTEGER, reason TEXT DEFAULT '');
        CREATE TABLE IF NOT EXISTS gifts(uid INTEGER PRIMARY KEY, discount INTEGER, status TEXT, created TEXT, expires TEXT);
        CREATE TABLE IF NOT EXISTS applications(id INTEGER PRIMARY KEY AUTOINCREMENT, uid INTEGER, kind TEXT, body TEXT, status TEXT DEFAULT 'new', created TEXT);
        CREATE TABLE IF NOT EXISTS support(id INTEGER PRIMARY KEY AUTOINCREMENT, uid INTEGER, body TEXT, created TEXT);
        CREATE TABLE IF NOT EXISTS services(id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT, description TEXT, price TEXT);
        """)
        for k in ("admin", "leader", "media"):
            c.execute("INSERT OR IGNORE INTO recruitment(kind,opened) VALUES(?,1)", (k,))
        if c.execute("SELECT COUNT(*) FROM services").fetchone()[0] == 0:
            c.executemany("INSERT INTO services(title,description,price) VALUES(?,?,?)", [
                ("Игровая валюта", "Пакеты игровой валюты", "Уточнить"),
                ("Транспорт", "Донат-транспорт", "Уточнить"),
                ("Скины", "Донат-скины", "Уточнить"),
                ("VIP-статус", "VIP-услуги", "Уточнить")])

def is_admin(uid): return uid in ADMINS
def now(): return datetime.now(timezone.utc)
def get_recruit(k):
    with conn() as c:
        r = c.execute("SELECT * FROM recruitment WHERE kind=?", (k,)).fetchone()
        return dict(r) if r else {"opened": 0, "reason": "Не настроено"}
def set_recruit(k, opened, reason=""):
    with conn() as c:
        c.execute("""INSERT INTO recruitment(kind,opened,reason) VALUES(?,?,?)
        ON CONFLICT(kind) DO UPDATE SET opened=excluded.opened,reason=excluded.reason""", (k,int(opened),reason))
def get_gift(uid):
    with conn() as c:
        r = c.execute("SELECT * FROM gifts WHERE uid=?", (uid,)).fetchone()
        return dict(r) if r else None
def save_gift(uid, discount, status, expires):
    with conn() as c:
        c.execute("""INSERT INTO gifts(uid,discount,status,created,expires) VALUES(?,?,?,?,?)
        ON CONFLICT(uid) DO UPDATE SET discount=excluded.discount,status=excluded.status,
        created=excluded.created,expires=excluded.expires""",
        (uid,discount,status,now().isoformat(),expires))
def gift_status(uid, status):
    with conn() as c: c.execute("UPDATE gifts SET status=? WHERE uid=?", (status,uid))

def menu():
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("📝 Подать заявку", callback_data="apply")],
        [InlineKeyboardButton("🏢 Организации", callback_data="orgs"), InlineKeyboardButton("🎬 Медиа", callback_data="media")],
        [InlineKeyboardButton("💎 Донат-услуги", callback_data="donate"), InlineKeyboardButton("🎁 Ежедневный подарок", callback_data="gift")],
        [InlineKeyboardButton("📜 Правила сервера", callback_data="rules")],
        [InlineKeyboardButton("🛠 Поддержка", callback_data="support"), InlineKeyboardButton("👤 Профиль", callback_data="profile")]
    ])
def back():
    return InlineKeyboardMarkup([[InlineKeyboardButton("⬅️ В меню", callback_data="home")]])

RULES = """📜 ПРАВИЛА WEZING RUSSIA

1. Запрещены читы и программы, дающие нечестное преимущество.
2. Запрещены оскорбления, угрозы, травля и дискриминация.
3. Запрещены спам, флуд и реклама без разрешения.
4. Запрещено злоупотреблять игровыми багами — сообщайте о них администрации.
5. Запрещено выдавать себя за администрацию или руководство.
6. Запрещены обман, мошенничество и кража аккаунтов.
7. Запрещено намеренно мешать игровому процессу других игроков.
8. Используйте допустимые никнеймы и уважайте участников проекта.
9. Запрещено публиковать личные данные других людей.
10. Жалобы подавайте спокойно и с доказательствами.
11. Выполняйте обоснованные требования администрации.
12. Незнание правил не освобождает от ответственности.

Наказание зависит от тяжести и повторности нарушения."""

async def start(u: Update, ctx: ContextTypes.DEFAULT_TYPE):
    user=u.effective_user
    with conn() as c:
        c.execute("INSERT INTO users(id,username,name) VALUES(?,?,?) ON CONFLICT(id) DO UPDATE SET username=excluded.username,name=excluded.name",
                  (user.id,user.username or "",user.first_name or ""))
    await u.message.reply_text("👋 Добро пожаловать на форум WEZING RUSSIA!\nВыберите раздел:", reply_markup=menu())

async def user_id(u,ctx):
    await u.message.reply_text(f"Ваш Telegram ID: {u.effective_user.id}")

async def admin(u,ctx):
    if not is_admin(u.effective_user.id):
        await u.message.reply_text("⛔ Нет доступа."); return
    kb=InlineKeyboardMarkup([
        [InlineKeyboardButton("🎬 Медиа: открыть",callback_data="adm:media:open"),InlineKeyboardButton("🎬 Медиа: закрыть",callback_data="adm:media:close")],
        [InlineKeyboardButton("👮 Админы: открыть",callback_data="adm:admin:open"),InlineKeyboardButton("👮 Админы: закрыть",callback_data="adm:admin:close")],
        [InlineKeyboardButton("👑 Лидеры: открыть",callback_data="adm:leader:open"),InlineKeyboardButton("👑 Лидеры: закрыть",callback_data="adm:leader:close")],
        [InlineKeyboardButton("📊 Статистика",callback_data="adm:stats")]])
    await u.message.reply_text("🛡 Панель владельца",reply_markup=kb)

async def cb(u: Update,ctx: ContextTypes.DEFAULT_TYPE):
    q=u.callback_query; await q.answer(); uid=q.from_user.id; d=q.data
    if d=="home": await q.edit_message_text("Главное меню:",reply_markup=menu()); return
    if d=="rules": await q.edit_message_text(RULES,reply_markup=back()); return
    if d=="orgs":
        await q.edit_message_text("🏢 Организации:\nЦБ • ВЧ • ОПГ ARZ • ОПГ BAT • ОПГ LYT • Право • СМИ • ГИБДД • УМВД",reply_markup=back()); return
    if d=="media":
        s=get_recruit("media")
        msg="🎬 Набор в медиа открыт!" if s["opened"] else "🔒 Набор в медиа закрыт.\nПричина: "+(s["reason"] or "Не указана")
        await q.edit_message_text(msg,reply_markup=back()); return
    if d=="apply":
        kb=InlineKeyboardMarkup([[InlineKeyboardButton("🛡 Администратор",callback_data="apply:admin")],
          [InlineKeyboardButton("👑 Лидер",callback_data="apply:leader")],[InlineKeyboardButton("🎬 Медиа",callback_data="apply:media")],
          [InlineKeyboardButton("⬅️ Назад",callback_data="home")]])
        await q.edit_message_text("Выберите направление:",reply_markup=kb); return
    if d.startswith("apply:"):
        k=d.split(":")[1]; s=get_recruit(k)
        if not s["opened"]:
            await q.edit_message_text("🔒 Набор временно закрыт.\n"+(s["reason"] or ""),reply_markup=back()); return
        ctx.user_data["application"]=k
        await q.edit_message_text("Отправьте анкету одним сообщением: ник, возраст, часовой пояс, онлайн и опыт."); return
    if d=="donate":
        with conn() as c: items=c.execute("SELECT * FROM services ORDER BY id").fetchall()
        rows=[[InlineKeyboardButton("Заказать: "+x["title"],callback_data=f"buy:{x['id']}")] for x in items]
        rows.append([InlineKeyboardButton("⬅️ В меню",callback_data="home")])
        text="💎 ДОНАТ-УСЛУГИ\n\n"+"\n".join(f"• {x['title']} — {x['price']}\n{x['description']}" for x in items)
        await q.edit_message_text(text,reply_markup=InlineKeyboardMarkup(rows)); return
    if d.startswith("buy:"):
        ctx.user_data["buy"]=d.split(":")[1]
        await q.edit_message_text("Напишите игровой ник и детали заказа одним сообщением.",reply_markup=back()); return
    if d=="gift":
        g=get_gift(uid)
        if g and g["status"] in ("claimed","deferred") and datetime.fromisoformat(g["created"])+timedelta(hours=24)>now():
            await q.edit_message_text(f"🎁 Ваш бонус: скидка {g['discount']}%. Статус: {g['status']}.",reply_markup=back()); return
        discount=random.randint(GIFT_MIN,GIFT_MAX); exp=(now()+timedelta(days=2)).isoformat()
        save_gift(uid,discount,"offered",exp)
        kb=InlineKeyboardMarkup([[InlineKeyboardButton("🎁 Забрать сейчас",callback_data="gift:claim")],
          [InlineKeyboardButton("⏳ Отложить на 2 дня",callback_data="gift:defer")],[InlineKeyboardButton("⬅️ В меню",callback_data="home")]])
        if ANIMATION:
            try: await ctx.bot.send_animation(uid,ANIMATION,caption="🎁 Для вас ежедневный подарок!")
            except Exception: log.exception("Animation send failed")
        await q.edit_message_text(f"🎁 ЕЖЕДНЕВНЫЙ ПОДАРОК\nВаша скидка: {discount}% на донат-услуги.\nВыберите действие:",reply_markup=kb); return
    if d in ("gift:claim","gift:defer"):
        g=get_gift(uid)
        if not g or g["status"] not in ("offered","deferred"):
            await q.edit_message_text("Подарок недоступен.",reply_markup=back()); return
        if d.endswith("claim"):
            gift_status(uid,"claimed")
            await q.edit_message_text(f"🎉 Скидка {g['discount']}% сохранена в профиле. Покажите это сообщение при заказе.",reply_markup=back())
        else:
            exp=(now()+timedelta(days=2)).isoformat(); save_gift(uid,g["discount"],"deferred",exp)
            await q.edit_message_text("⏳ Подарок отложен на 2 дня. После срока он исчезнет.",reply_markup=back())
        return
    if d=="profile":
        g=get_gift(uid); msg="👤 Профиль"
        if g: msg+=f"\n🎁 Скидка: {g['discount']}% | {g['status']}"
        await q.edit_message_text(msg,reply_markup=back()); return
    if d=="support":
        ctx.user_data["support"]=True
        await q.edit_message_text("Напишите обращение в поддержку:",reply_markup=back()); return
    if d.startswith("adm:"):
        if not is_admin(uid): await q.edit_message_text("⛔ Нет доступа."); return
        _,k,action=d.split(":")
        if k=="stats":
            with conn() as c:
                users=c.execute("SELECT COUNT(*) FROM users").fetchone()[0]
                apps=c.execute("SELECT COUNT(*) FROM applications").fetchone()[0]
            await q.edit_message_text(f"📊 Пользователей: {users}\nЗаявок: {apps}",reply_markup=back()); return
        if action=="open":
            set_recruit(k,True,""); await q.edit_message_text(f"✅ Набор {k} открыт.",reply_markup=back())
        else:
            ctx.user_data["closing"]=k
            await q.edit_message_text("Отправьте причину закрытия набора одним сообщением."); return

async def text_msg(u,ctx):
    uid=u.effective_user.id; body=u.message.text or ""
    if "closing" in ctx.user_data:
        k=ctx.user_data.pop("closing"); set_recruit(k,False,body)
        await u.message.reply_text(f"🔒 Набор {k} закрыт. Причина: {body}",reply_markup=menu()); return
    if "application" in ctx.user_data:
        k=ctx.user_data.pop("application")
        with conn() as c:
            cur=c.execute("INSERT INTO applications(uid,kind,body,created) VALUES(?,?,?,?)",(uid,k,body,now().isoformat()))
            aid=cur.lastrowid
        for a in ADMINS:
            try: await ctx.bot.send_message(a,f"📝 Заявка #{aid}\nТип: {k}\nИгрок: {uid}\n\n{body}")
            except Exception: pass
        await u.message.reply_text("✅ Заявка отправлена администрации.",reply_markup=menu()); return
    if "buy" in ctx.user_data:
        item=ctx.user_data.pop("buy")
        for a in ADMINS:
            try: await ctx.bot.send_message(a,f"💎 Заказ услуги #{item} от {uid}:\n{body}")
            except Exception: pass
        await u.message.reply_text("✅ Заказ отправлен администрации. Оплата пока согласуется вручную.",reply_markup=menu()); return
    if ctx.user_data.pop("support",False):
        with conn() as c: c.execute("INSERT INTO support(uid,body,created) VALUES(?,?,?)",(uid,body,now().isoformat()))
        for a in ADMINS:
            try: await ctx.bot.send_message(a,f"🆘 Поддержка от {uid}:\n{body}")
            except Exception: pass
        await u.message.reply_text("✅ Обращение отправлено.",reply_markup=menu()); return
    await u.message.reply_text("Используйте кнопки меню:",reply_markup=menu())

async def expiry_job(ctx):
    with conn() as c: rows=c.execute("SELECT uid FROM gifts WHERE status='deferred' AND expires<=?",(now().isoformat(),)).fetchall()
    for row in rows:
        uid=row["uid"]
        try: await ctx.bot.send_message(uid,"⌛ Ваш отложенный подарок WEZING RUSSIA истёк и исчез.")
        except Exception as e: log.warning("Expiry notification failed: %s",e)
        gift_status(uid,"expired")

def run_web(): web.run(host="0.0.0.0",port=PORT)
def main():
    if not TOKEN: raise RuntimeError("Set BOT_TOKEN in Render Environment.")
    init_db()
    Thread(target=run_web,daemon=True).start()
    app=Application.builder().token(TOKEN).build()
    app.add_handler(CommandHandler("start",start))
    app.add_handler(CommandHandler("id",user_id))
    app.add_handler(CommandHandler("admin",admin))
    app.add_handler(CallbackQueryHandler(cb))
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND,text_msg))
    app.job_queue.run_repeating(expiry_job,interval=300,first=30)
    app.run_polling(drop_pending_updates=True)
if __name__=="__main__": main()
